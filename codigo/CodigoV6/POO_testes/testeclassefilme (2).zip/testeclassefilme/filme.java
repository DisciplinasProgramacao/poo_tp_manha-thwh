import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.security.InvalidParameterException;
import java.time.LocalDate;

class FilmeTest {

    @Test
    void testConstrutorPadrao() {
        Filme filme = new Filme();
        assertNotNull(filme);
    }

    @Test
    void testConstrutorComParametros() {
        int id = 1;
        String nome = "Filme Teste";
        LocalDate dataLancamento = LocalDate.now();
        double duracao = 120.5;
        int genero = 1;
        int idioma = 1;

        try {
            Filme filme = new Filme(id, nome, dataLancamento, duracao, genero, idioma);
            assertEquals(id, filme.getID_Filme());
            assertEquals(nome, filme.getNome());
            assertEquals(dataLancamento, filme.getDataLancamento());
            assertEquals(duracao, filme.getDuracao());
        } catch (InvalidParameterException e) {
            fail("Lançou exceção inválida: " + e.getMessage());
        }
    }

    @Test
    void testConstrutorComDuracaoInvalida() {
        int id = 1;
        String nome = "Filme Teste";
        LocalDate dataLancamento = LocalDate.now();
        double duracao = 0.5;
        int genero = 1;
        int idioma = 1;

        assertThrows(InvalidParameterException.class, () -> {
            new Filme(id, nome, dataLancamento, duracao, genero, idioma);
        });
    }

    @Test
    void testToString() {
        int id = 1;
        String nome = "Filme Teste";
        LocalDate dataLancamento = LocalDate.now();
        double duracao = 120.5;
        int genero = 1;
        int idioma = 1;

        try {
            Filme filme = new Filme(id, nome, dataLancamento, duracao, genero, idioma);
            String expected = id + ";" + nome + ";" + dataLancamento + ";" + duracao;
            assertEquals(expected, filme.toString());
        } catch (InvalidParameterException e) {
            fail("Lançou exceção inválida: " + e.getMessage());
        }
    }
}
