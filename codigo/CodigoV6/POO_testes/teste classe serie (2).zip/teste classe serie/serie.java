import java.security.InvalidParameterException;
import java.time.LocalDate;

public class SerieTest {

    public static void main(String[] args) {
        testConstrutorPadrao();
        testConstrutorComParametrosValidos();
        testConstrutorComQuantidadeEpisodiosZero();
        testGetQuantidadeEpisodios();
        testGetID_Serie();
        testToString();
    }

    public static void testConstrutorPadrao() {
        Serie serie = new Serie();
        // Verificar se os atributos foram inicializados corretamente
        assert serie.getId() == 0;
        assert serie.getNome() == null;
        assert serie.getDataLancamento() == null;
        assert serie.getQuantidadeEpisodios() == 0;
    }

    public static void testConstrutorComParametrosValidos() {
        int id = 1;
        String nome = "Série de Teste";
        LocalDate dataLancamento = LocalDate.of(2022, 1, 1);
        int quantidadeEpisodios = 10;

        Serie serie = new Serie(id, nome, dataLancamento, quantidadeEpisodios);

        // Verificar se os atributos foram definidos corretamente
        assert serie.getId() == id;
        assert serie.getNome().equals(nome);
        assert serie.getDataLancamento().equals(dataLancamento);
        assert serie.getQuantidadeEpisodios() == quantidadeEpisodios;
    }

    public static void testConstrutorComQuantidadeEpisodiosZero() {
        try {
            Serie serie = new Serie(1, "Série de Teste", LocalDate.now(), 0);
            // Se uma exceção não for lançada, o teste falhou
            assert false;
        } catch (InvalidParameterException e) {
            // Verificar se a exceção foi lançada corretamente
            assert e.getMessage().equals("!!! A QUANTIDADE DE EPISÓDIOS NÃO PODE SER 0 !!!");
        }
    }

    public static void testGetQuantidadeEpisodios() {
        int quantidadeEpisodios = 10;
        Serie serie = new Serie(1, "Série de Teste", LocalDate.now(), quantidadeEpisodios);

        // Verificar se o método getQuantidadeEpisodios retorna o valor correto
        assert serie.getQuantidadeEpisodios() == quantidadeEpisodios;
    }

    public static void testGetID_Serie() {
        int id = 1;
        Serie serie = new Serie(id, "Série de Teste", LocalDate.now(), 10);

        // Verificar se o método getID_Serie retorna o valor correto
        assert serie.getID_Serie() == id;
    }

    public static void testToString() {
        int id = 1;
        String nome = "Série de Teste";
        LocalDate dataLancamento = LocalDate.of(2022, 1, 1);
        Serie serie = new Serie(id, nome, dataLancamento, 10);

        // Verificar se o método toString retorna a representação correta da série
        String expectedString = id + ";" + nome + ";" + dataLancamento;
        assert serie.toString().equals(expectedString);
    }

}
