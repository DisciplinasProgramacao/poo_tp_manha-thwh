import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.security.InvalidParameterException;
import java.time.LocalDate;
import java.util.HashMap;

public class MidiaTest {

    private Midia midia;

    @Before
    public void setUp() {
        // Configuração inicial para cada teste
        midia = new MidiaMock();
    }

    @Test
    public void adicionarAvaliacao_DeveAdicionarAvaliacao() {
        Avaliacao avaliacao = new Avaliacao(4, new Espectador());
        
        midia.adicionarAvaliacao(avaliacao);

        HashMap<Avaliacao, Espectador> avaliacoes = midia.getAvaliacoes();
        assertTrue(avaliacoes.containsKey(avaliacao));
    }

    @Test
    public void calcularMediaDeNotas_SemAvaliacoes_DeveRetornarZero() {
        double media = midia.calcularMediaDeNotas();

        assertEquals(0, media, 0.001);
    }

    @Test
    public void calcularMediaDeNotas_ComAvaliacoes_DeveCalcularMediaCorretamente() {
        Avaliacao avaliacao1 = new Avaliacao(5, new Espectador());
        Avaliacao avaliacao2 = new Avaliacao(3, new Espectador());
        Avaliacao avaliacao3 = new Avaliacao(4, new Espectador());

        midia.adicionarAvaliacao(avaliacao1);
        midia.adicionarAvaliacao(avaliacao2);
        midia.adicionarAvaliacao(avaliacao3);

        double media = midia.calcularMediaDeNotas();

        assertEquals(4, media, 0.001);
    }

    @Test
    public void isLancamento_DataLancamentoFutura_DeveRetornarFalse() {
        midia.setDataLancamento(LocalDate.now().plusDays(1));

        boolean isLancamento = midia.isLancamento();

        assertFalse(isLancamento);
    }

    @Test
    public void isLancamento_DataLancamentoPassada_DeveRetornarTrue() {
        midia.setDataLancamento(LocalDate.now().minusDays(1));

        boolean isLancamento = midia.isLancamento();

        assertTrue(isLancamento);
    }

    @Test
    public void verificarAcessoLancamento_EspectadorProfissionalAcessoAoLancamento_DeveRetornarTrue() {
        Espectador espectador = new Espectador();
        espectador.setTipoEspectador(TipoEspectador.PROFISSIONAL);
        midia.setDataLancamento(LocalDate.now().minusDays(1));

        boolean temAcesso = midia.verificarAcessoLancamento(espectador);

        assertTrue(temAcesso);
    }

    @Test
    public void verificarAcessoLancamento_EspectadorNaoProfissionalAcessoAoLancamento_DeveRetornarFalse() {
        Espectador espectador = new Espectador();
        espectador.setTipoEspectador(TipoEspectador.NORMAL);
        midia.setDataLancamento(LocalDate.now().minusDays(1));

        boolean temAcesso = midia.verificarAcessoLancamento(espectador);

        assertFalse(temAcesso);
    }

    @Test
    public void adicionarComentario_EspectadorProfissional_DeveAdicionarComentario() {
        Espectador espectador = new Espectador();
        espectador.setTipoEspectador(TipoEspectador.PROFISSIONAL);
        String comentario = "Ótima mídia!";

        midia.adicionarComentario(espectador, comentario);

        assertTrue(midia.getComentarios().contains(comentario));
    }

    @Test
    public void adicionarComentario_EspectadorNaoProfissional_NaoDeveAdicionarComentario() {
        Espectador espectador = new Espectador();
        espectador.setTipoEspectador(TipoEspectador.NORMAL);
        String comentario = "Ótima mídia!";

        midia.adicionarComentario(espectador, comentario);

        assertFalse(midia.getComentarios().contains(comentario));
    }

    // Implementação de uma subclasse para usar como mock
    private class MidiaMock extends Midia {
        // Implementação dos métodos abstratos, caso existam

        // Implementação dos métodos abstratos, caso existam
    }
}
