package exceptions;

public class EspectadorAvaliaException extends Exception {
   

	public EspectadorAvaliaException() {
        super("Voc� precisa ter visto a m�dia para poder avalia-l�");
    }
}
