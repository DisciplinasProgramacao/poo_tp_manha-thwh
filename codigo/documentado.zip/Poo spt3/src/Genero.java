/**
 * Enumerador para os g�neros dispon�veis.
 */
enum Genero {
    ACAO,         // Valor do tipo Genero para A��o
    ANIME,        // Valor do tipo Genero para Anime
    AVENTURA,     // Valor do tipo Genero para Aventura
    COMEDIA,      // Valor do tipo Genero para Com�dia
    DOCUMENTARIO, // Valor do tipo Genero para Document�rio
    DRAMA,        // Valor do tipo Genero para Drama
    POLICIAL,     // Valor do tipo Genero para Policial
    ROMANCE,      // Valor do tipo Genero para Romance
    SUSPENSE;     // Valor do tipo Genero para Suspense
}