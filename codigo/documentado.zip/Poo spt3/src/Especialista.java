import java.security.InvalidParameterException;
import java.util.Map;

/**
 * Interface que define um Especialista.
 */
public interface Especialista {

    /**
     * Comenta sobre uma determinada m�dia.
     *
     * @param midia      A m�dia sobre a qual o coment�rio ser� feito
     * @param comentario O coment�rio a ser adicionado
     * @throws InvalidParameterException Se um par�metro inv�lido for fornecido
     */
    public void Comentar(Midia midia, String comentario) throws InvalidParameterException;

    /**
     * Obt�m um mapa de m�dias e seus respectivos coment�rios.
     *
     * @return O mapa contendo as m�dias e seus coment�rios
     */
    public Map<Midia, String> getComentarios();
}
