
/**
 * Enumerador para os idiomas dispon�veis.
 */
enum Idioma {
    INGLES,     // Valor do tipo Idioma para Ingl�s
    PORTUGUES,  // Valor do tipo Idioma para Portugu�s
    ESPANHOL,   // Valor do tipo Idioma para Espanhol
    JAPON�S,    // Valor do tipo Idioma para Japon�s
    COREANO,    // Valor do tipo Idioma para Coreano
    RUSSO,      // Valor do tipo Idioma para Russo
    MANDARIM,   // Valor do tipo Idioma para Mandarim
    ALEM�O,     // Valor do tipo Idioma para Alem�o
    �RABE       // Valor do tipo Idioma para �rabe
}