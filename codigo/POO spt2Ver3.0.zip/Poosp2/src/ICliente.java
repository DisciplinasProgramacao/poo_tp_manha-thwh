
// Interface ICliente
interface ICliente {
    void atribuirNota(int idMidia, int nota);
}